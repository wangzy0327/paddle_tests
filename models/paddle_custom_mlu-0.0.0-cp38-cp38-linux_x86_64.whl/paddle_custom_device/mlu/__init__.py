# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
full_version  = '0.0.0'
git_commit_id = '2933991d903200f58ed187385201ae4f6622cb52'
cntoolkit_version  = '3.7.0'
cnnl_version  = '1.21.1'
cncl_version  = '1.13.0'
mluops_version  = '0.9.0'

__all__ = ['version']

def version():
    """Get the version info of paddle custom mlu

    Returns:
        version: version of paddle custom mlu
        commit: the commit id of paddle custom mlu
        cann: the cann version of paddle custom mlu

    Examples:
        .. code-block:: python

            import paddle_custom_device

            paddle_custom_device.mlu.version()
            # version: 0.0.0
            # commit: 98ae7a84b51e36fc15a1fef7808a82ed8b792fdf
            # cntoolkit: 3.4.2
            # cnnl: 1.17.0
            # cncl: 1.9.3
            # mluops: 0.6.0
    """
    print('version:', full_version)
    print('commit:', git_commit_id)
    print('cntoolkit:', cntoolkit_version)
    print('cnnl:', cnnl_version)
    print('cncl:', cncl_version)
    print('mluops:', mluops_version)
