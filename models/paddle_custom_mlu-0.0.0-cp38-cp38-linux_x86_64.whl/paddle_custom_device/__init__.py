# THIS FILE IS GENERATED FROM PADDLEPADDLE SETUP.PY
#
from . import mlu # noqa: F401

__all__ = [  # noqa
    'mlu',
]

